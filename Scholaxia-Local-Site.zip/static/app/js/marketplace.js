(function () {
  var api = window.ScholaxiaAPI;
  var products = [];
  var activeCat = "all";
  var searchQuery = "";
  var guestCart = [];
  var CART_KEY = "sia_market_guest_cart";

  function $(id) {
    return document.getElementById(id);
  }

  // ── Currency helpers ──────────────────────────────────────────────────────
  var MKT_CURRENCIES = {
    USD: { symbol: "$",    rate: 1 / 1650 },
    GBP: { symbol: "£",    rate: 0.79 / 1650 },
    NGN: { symbol: "₦",   rate: 1 },
    KES: { symbol: "KES ", rate: 130 / 1650 },
    GHS: { symbol: "GHS ", rate: 13.5 / 1650 },
  };

  function getCurrency() {
    var code = localStorage.getItem("sx_currency") || "NGN";
    return MKT_CURRENCIES[code] ? code : "NGN";
  }

  function money(ngnAmount) {
    var code = getCurrency();
    var cur = MKT_CURRENCIES[code];
    var converted = (Number(ngnAmount) || 0) * cur.rate;
    var formatted = code === "NGN"
      ? Math.round(converted).toLocaleString("en-NG")
      : converted.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    return cur.symbol + formatted;
  }

  // Hook currency picker so re-renders marketplace prices when changed.
  // i18n.js dispatches 'sx:currencychange' from inside applyCurrency, so this
  // works for the header dropdown and any SxCurr.apply() call alike.
  var _mktCurrHooked = false;
  function hookMktCurrency() {
    if (_mktCurrHooked) return;
    _mktCurrHooked = true;
    document.addEventListener("sx:currencychange", function () {
      renderGrid(); // re-render all product cards with new currency
      // (cart totals are re-rendered by renderCartBody() every time the cart opens)
    });
    // Also wire the inline dropdown on this page (marketplace.css has no
    // .lang-wrap.open rules, so open/close uses inline display like before).
    var wrap = document.getElementById("currWrap");
    var btn  = document.getElementById("currBtn");
    var dd   = document.getElementById("currDropdown");
    if (btn && wrap && dd) {
      // Show/hide
      btn.addEventListener("click", function(e) {
        e.stopPropagation();
        var open = dd.style.display === "block";
        dd.style.display = open ? "none" : "block";
        btn.setAttribute("aria-expanded", String(!open));
      });
      dd.addEventListener("click", function(e) {
        var opt = e.target.closest(".lang-option");
        if (!opt || !opt.dataset.currency) return;
        var code = opt.dataset.currency;
        dd.querySelectorAll(".lang-option").forEach(function(o) { o.style.fontWeight = ""; });
        opt.style.fontWeight = "700";
        if (window.SxCurr) {
          window.SxCurr.apply(code); // updates label + localStorage + fires event
        } else {
          var sym = { USD:"$", GBP:"£", NGN:"₦", KES:"KES ", GHS:"GHS " }[code] || "";
          var symEl = document.getElementById("currSymbol");
          var lblEl = document.getElementById("currLabel");
          if (symEl) symEl.textContent = sym.trim();
          if (lblEl) lblEl.textContent = code;
          localStorage.setItem("sx_currency", code);
          renderGrid();
        }
        dd.style.display = "none";
      });
      document.addEventListener("click", function() { dd.style.display = "none"; });
    }
  }
  hookMktCurrency();
  document.addEventListener("DOMContentLoaded", hookMktCurrency);

  function toast(msg) {
    var el = $("mktToast");
    if (!el) return;
    el.textContent = msg;
    el.hidden = false;
    clearTimeout(toast._t);
    toast._t = setTimeout(function () {
      el.hidden = true;
    }, 2600);
  }

  function isBuyerLoggedIn() {
    var role = (localStorage.getItem("sia_role") || "").toLowerCase();
    return !!(api.getToken() && (role === "student" || role === "kind"));
  }

  function loadGuestCart() {
    try {
      guestCart = JSON.parse(localStorage.getItem(CART_KEY) || "[]") || [];
    } catch (e) {
      guestCart = [];
    }
  }

  function saveGuestCart() {
    localStorage.setItem(CART_KEY, JSON.stringify(guestCart));
  }

  function cartCount() {
    if (isBuyerLoggedIn()) return cartCount._server || 0;
    return guestCart.reduce(function (sum, it) {
      return sum + (it.quantity || 1);
    }, 0);
  }

  function setCartBadge() {
    var el = $("cartCount");
    if (el) el.textContent = String(cartCount());
  }

  function openRoleModal() {
    $("roleModal").hidden = false;
  }

  function closeRoleModal() {
    $("roleModal").hidden = true;
  }

  function openCheckoutModal() {
    $("checkoutModal").hidden = false;
  }

  function closeCheckoutModal() {
    $("checkoutModal").hidden = true;
  }

  function marketAuthUrl(pick, mode) {
    var base = "portal.html?market=1&mode=" + (mode || "signup");
    if (pick === "vendor") {
      return (
        base +
        "&role=vendor&next=" +
        encodeURIComponent("marketplace.html?vendor=pending")
      );
    }
    return (
      base +
      "&role=student&next=" +
      encodeURIComponent("marketplace.html?checkout=1")
    );
  }

  function goAuth(pick) {
    window.location.href = marketAuthUrl(pick, "signup");
  }

  async function syncServerCartCount() {
    if (!isBuyerLoggedIn()) {
      cartCount._server = 0;
      setCartBadge();
      return;
    }
    try {
      var cart = await api.api("/api/v1/marketplace/cart");
      var items = (cart && cart.items) || [];
      cartCount._server = items.reduce(function (s, it) {
        return s + (it.quantity || 1);
      }, 0);
    } catch (e) {
      cartCount._server = 0;
    }
    setCartBadge();
  }

  async function flushGuestCartToServer() {
    if (!isBuyerLoggedIn() || !guestCart.length) return;
    for (var i = 0; i < guestCart.length; i++) {
      var it = guestCart[i];
      try {
        await api.api("/api/v1/marketplace/cart/add", {
          method: "POST",
          body: { product_id: it.product_id, quantity: it.quantity || 1 },
        });
      } catch (e) { /* skip bad lines */ }
    }
    guestCart = [];
    saveGuestCart();
  }

  function filteredProducts() {
    var list =
      activeCat === "all"
        ? products.slice()
        : products.filter(function (p) {
            return (p.category || "").toLowerCase() === activeCat;
          });
    var q = searchQuery.trim().toLowerCase();
    if (!q) return list;
    return list.filter(function (p) {
      var hay = [
        p.title,
        p.name,
        p.description,
        p.category,
      ]
        .join(" ")
        .toLowerCase();
      return hay.indexOf(q) >= 0;
    });
  }

  function renderTabs() {
    var wrap = $("mktTabs");
    if (!wrap) return;
    var cats = ["all"].concat(
      Array.from(
        new Set(
          products
            .map(function (p) {
              return (p.category || "").toLowerCase();
            })
            .filter(Boolean)
        )
      )
    );
    wrap.innerHTML = cats
      .map(function (c) {
        var label = c === "all" ? "All" : c.charAt(0).toUpperCase() + c.slice(1);
        return (
          '<button type="button" class="mkt-tab' +
          (c === activeCat ? " is-active" : "") +
          '" data-cat="' +
          c +
          '">' +
          label +
          "</button>"
        );
      })
      .join("");
  }

  function renderGrid() {
    var grid = $("mktGrid");
    if (!grid) return;
    var list = filteredProducts();
    if (!list.length) {
      grid.innerHTML = '<div class="mkt-empty">No products match this filter yet.</div>';
      return;
    }
    grid.innerHTML = list
      .map(function (p, i) {
        var img = p.image_url || p.secure_url || "";
        var desc = (p.description || "").trim();
        var price = Number(p.price || 0);
        return (
          '<article class="mkt-item mkt-item-enter" style="animation-delay:' +
          Math.min(i, 14) * 0.09 +
          's">' +
          '<div class="mkt-item-media">' +
          (img
            ? '<img src="' +
              img.replace(/"/g, "") +
              '" alt="" loading="lazy" />'
            : '<div class="mkt-media-ph" aria-hidden="true">🛍️</div>') +
          "</div>" +
          '<div class="mkt-item-body">' +
          '<p class="mkt-item-cat">' +
          escapeHtml(p.category || "item") +
          "</p>" +
          '<h3 class="mkt-item-title">' +
          escapeHtml(p.title || "Product") +
          "</h3>" +
          (desc
            ? '<p class="mkt-item-desc">' + escapeHtml(desc) + "</p>"
            : "") +
          '<div class="mkt-item-foot">' +
          '<span class="mkt-price">' +
          (price > 0 ? money(price) : "Ask price") +
          "</span>" +
          '<button type="button" class="mkt-add" data-add="' +
          escapeHtml(String(p.id || "")) +
          '">Add to cart</button>' +
          "</div></div></article>"
        );
      })
      .join("");
  }

  function productImageUrl(p) {
    if (!p) return "";
    return String(p.image_url || p.secure_url || "").trim();
  }

  function escapeHtml(s) {
    return String(s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function cartRowHtml(title, qty, linePrice, removeHtml, imageUrl) {
    var thumb = imageUrl
      ? '<img class="mkt-cart-thumb" src="' +
        escapeHtml(imageUrl.replace(/"/g, "")) +
        '" alt="" />'
      : '<div class="mkt-cart-thumb mkt-cart-thumb-empty" aria-hidden="true"></div>';
    return (
      '<div class="mkt-cart-row">' +
      thumb +
      '<div class="mkt-cart-meta">' +
      "<strong>" +
      escapeHtml(title) +
      "</strong>" +
      "<span>Qty " +
      qty +
      " · " +
      money(linePrice) +
      "</span>" +
      "</div>" +
      removeHtml +
      "</div>"
    );
  }

  async function addToCart(productId) {
    var product = products.filter(function (p) {
      return String(p.id) === String(productId);
    })[0];
    if (!product) return;
    if (!(Number(product.price) > 0)) {
      toast("This item has no checkout price yet.");
      return;
    }

    if (!isBuyerLoggedIn()) {
      var existing = guestCart.filter(function (it) {
        return String(it.product_id) === String(productId);
      })[0];
      if (existing) {
        existing.quantity = (existing.quantity || 1) + 1;
        if (!existing.image_url) existing.image_url = productImageUrl(product);
      } else {
        guestCart.push({
          product_id: productId,
          title: product.title,
          price: product.price,
          quantity: 1,
          image_url: productImageUrl(product),
        });
      }
      saveGuestCart();
      setCartBadge();
      toast("Added — sign in at checkout");
      return;
    }

    try {
      await api.api("/api/v1/marketplace/cart/add", {
        method: "POST",
        body: { product_id: productId, quantity: 1 },
      });
      await syncServerCartCount();
      toast("Added to cart");
    } catch (err) {
      toast(err.message || "Could not add to cart");
    }
  }

  async function renderCartBody() {
    var body = $("cartBody");
    var totalEl = $("cartTotal");
    if (!body) return;

    if (isBuyerLoggedIn()) {
      try {
        var cart = await api.api("/api/v1/marketplace/cart");
        var items = (cart && cart.items) || [];
        cartCount._server = items.reduce(function (s, it) {
          return s + (it.quantity || 1);
        }, 0);
        setCartBadge();
        if (!items.length) {
          body.innerHTML = '<p class="mkt-empty">Your cart is empty.</p>';
          if (totalEl) totalEl.textContent = money(0);
          return;
        }
        body.innerHTML = items
          .map(function (it) {
            var title =
              (it.product && it.product.title) || it.title || "Product";
            var img = productImageUrl(it.product) || it.image_url || "";
            return cartRowHtml(
              title,
              it.quantity || 1,
              it.line_total || 0,
              '<button type="button" data-remove="' +
                escapeHtml(String(it.id || "")) +
                '">Remove</button>',
              img
            );
          })
          .join("");
        if (totalEl) totalEl.textContent = money(cart.total_amount || 0);
      } catch (err) {
        body.innerHTML =
          '<p class="mkt-empty">' +
          escapeHtml(err.message || "Could not load cart") +
          "</p>";
      }
      return;
    }

    if (!guestCart.length) {
      body.innerHTML = '<p class="mkt-empty">Your cart is empty.</p>';
      if (totalEl) totalEl.textContent = money(0);
      return;
    }
    var total = 0;
    body.innerHTML = guestCart
      .map(function (it, idx) {
        var line = (Number(it.price) || 0) * (it.quantity || 1);
        total += line;
        return cartRowHtml(
          it.title || "Product",
          it.quantity || 1,
          line,
          '<button type="button" data-remove-guest="' + idx + '">Remove</button>',
          it.image_url || ""
        );
      })
      .join("");
    if (totalEl) totalEl.textContent = money(total);
  }

  async function openCart() {
    $("cartDrawer").hidden = false;
    await renderCartBody();
  }

  function closeCart() {
    $("cartDrawer").hidden = true;
  }

  async function beginCheckout() {
    if (!isBuyerLoggedIn()) {
      openRoleModal();
      return;
    }
    if (guestCart.length) await flushGuestCartToServer();
    await renderCartBody();
    if (isBuyerLoggedIn() && !(cartCount._server > 0) && !guestCart.length) {
      toast("Your cart is empty.");
      return;
    }
    openCheckoutModal();
  }

  async function submitCheckout(e) {
    e.preventDefault();
    var address = $("checkoutAddress").value.trim();
    var phone = $("checkoutPhone").value.trim();
    if (address.length < 5) {
      toast("Enter a fuller delivery address.");
      return;
    }
    if (phone.length < 7) {
      toast("Enter a valid phone number.");
      return;
    }

    var btn = e.target.querySelector('button[type="submit"]');
    if (btn) {
      btn.disabled = true;
      btn.textContent = "Creating order…";
    }

    try {
      var res = await api.api("/api/v1/marketplace/checkout", {
        method: "POST",
        body: {
          delivery_address: address,
          contact_phone: phone,
        },
      });
      var orderId = res && res.order_id;
      if (!orderId) throw new Error("Checkout did not return an order id.");

      closeCheckoutModal();
      closeCart();

      if (typeof window.paystackPurchase === "function") {
        await window.paystackPurchase({
          productType: "marketplace_order",
          productId: orderId,
          returnPage: "marketplace",
        });
        return;
      }
      toast("Order created. Complete payment from My orders.");
    } catch (err) {
      toast(err.message || "Checkout failed");
    } finally {
      if (btn) {
        btn.disabled = false;
        btn.textContent = "Pay with Paystack";
      }
    }
  }

  async function loadOrders() {
    if (!isBuyerLoggedIn()) {
      window.location.href =
        "portal.html?market=1&mode=login&role=student&next=" +
        encodeURIComponent("marketplace.html");
      return;
    }
    try {
      var data = await api.api("/api/v1/marketplace/orders");
      var orders = Array.isArray(data)
        ? data
        : (data && (data.orders || data.items || data.results)) || [];
      if (!orders.length) {
        toast("No orders yet — checkout from your cart.");
        return;
      }
      var lines = orders
        .slice(0, 5)
        .map(function (o) {
          return (
            (o.status || "order") +
            " · " +
            money(o.total_amount || o.amount || 0)
          );
        })
        .join(" | ");
      toast(lines);
    } catch (err) {
      toast(err.message || "Could not load orders");
    }
  }

  async function loadProducts() {
    var grid = $("mktGrid");
    try {
      var data = await api.api("/api/v1/marketplace/products", { noAuth: true });
      products = Array.isArray(data)
        ? data
        : (data && (data.products || data.items || data.results)) || [];
      renderTabs();
      renderGrid();
    } catch (err) {
      if (grid) {
        grid.innerHTML =
          '<div class="mkt-empty">' +
          escapeHtml(err.message || "Could not load products") +
          "</div>";
      }
    }
  }

  function initHeroSlider() {
    var slides = document.querySelectorAll(".mkt-hero-slide");
    if (slides.length < 2) return;
    var idx = 0;
    setInterval(function () {
      idx = (idx + 1) % slides.length;
      slides.forEach(function (s, i) {
        s.classList.toggle("is-active", i === idx);
      });
    }, 3800);
  }

  document.addEventListener("DOMContentLoaded", async function () {
    initHeroSlider();
    loadGuestCart();
    setCartBadge();

    if (typeof window.resumePendingPaystack === "function") {
      try {
        var payRes = await window.resumePendingPaystack();
        if (payRes && payRes.paid) {
          toast("Payment confirmed — thank you!");
        }
      } catch (e) { /* ignore */ }
    }

    var params = new URLSearchParams(window.location.search);
    if (params.get("vendor") === "pending") {
      var banner = $("vendorBanner");
      if (banner) banner.hidden = false;
      toast("Vendor signup received — wait for admin approval.");
    }

    if (isBuyerLoggedIn()) {
      $("btnOrders").hidden = false;
      await flushGuestCartToServer();
      await syncServerCartCount();
      if (params.get("checkout") === "1") openCart();
    }

    await loadProducts();

    $("mktTabs").addEventListener("click", function (e) {
      var btn = e.target.closest("[data-cat]");
      if (!btn) return;
      activeCat = btn.dataset.cat;
      renderTabs();
      renderGrid();
    });

    var search = $("mktSearch");
    if (search) {
      search.addEventListener("input", function () {
        searchQuery = search.value || "";
        renderGrid();
      });
    }

    $("mktGrid").addEventListener("click", function (e) {
      var btn = e.target.closest("[data-add]");
      if (!btn) return;
      addToCart(btn.dataset.add);
    });

    $("btnCart").addEventListener("click", openCart);
    $("closeCart").addEventListener("click", closeCart);
    $("cartDrawer").addEventListener("click", function (e) {
      if (e.target === $("cartDrawer")) closeCart();
    });
    $("btnCheckout").addEventListener("click", beginCheckout);
    $("btnSell").addEventListener("click", function () {
      goAuth("vendor");
    });
    var btnJoin = $("btnJoin");
    if (btnJoin) {
      btnJoin.addEventListener("click", openRoleModal);
    }
    $("closeRole").addEventListener("click", closeRoleModal);
    $("roleModal").addEventListener("click", function (e) {
      if (e.target === $("roleModal")) closeRoleModal();
      var pick = e.target.closest("[data-pick]");
      if (pick) goAuth(pick.dataset.pick);
    });
    $("closeCheckout").addEventListener("click", closeCheckoutModal);
    $("checkoutModal").addEventListener("click", function (e) {
      if (e.target === $("checkoutModal")) closeCheckoutModal();
    });
    $("checkoutForm").addEventListener("submit", submitCheckout);

    $("cartBody").addEventListener("click", async function (e) {
      var rm = e.target.closest("[data-remove]");
      if (rm) {
        try {
          await api.api("/api/v1/marketplace/cart/" + rm.dataset.remove, {
            method: "DELETE",
          });
          await renderCartBody();
          await syncServerCartCount();
        } catch (err) {
          toast(err.message || "Could not remove item");
        }
        return;
      }
      var rg = e.target.closest("[data-remove-guest]");
      if (rg) {
        guestCart.splice(Number(rg.dataset.removeGuest), 1);
        saveGuestCart();
        setCartBadge();
        renderCartBody();
      }
    });

    $("btnOrders").addEventListener("click", loadOrders);

    // Vendor hero image fallback → show text card if the banner fails to load
    var vHero = document.querySelector(".mkt-hero-vendor-rich");
    if (vHero) {
      var vImg = vHero.querySelector(".mkt-vendor-hero-img");
      if (vImg && vImg.complete && vImg.naturalWidth === 0) vHero.classList.add("img-failed");
      if (vImg) vImg.addEventListener("error", function () { vHero.classList.add("img-failed"); });
    }
  });
})();
