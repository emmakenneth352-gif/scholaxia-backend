import uuid
from datetime import datetime
from sqlalchemy import String, Boolean, DateTime, Enum, ForeignKey, Integer
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from app.core.database import Base
import enum


class UserRole(str, enum.Enum):
    student = "student"
    teacher = "teacher"
    vendor = "vendor"
    kind = "kind"           # young learners (kids / primary)
    admin = "admin"
    school_admin = "school_admin"
    developer = "developer"   # external API developers


class ExamType(str, enum.Enum):
    JAMB = "JAMB"
    WAEC = "WAEC"
    NECO = "NECO"
    JUNIOR_WAEC = "JUNIOR_WAEC"  # BECE / Junior WAEC for JSS1–3
    POST_UTME = "POST_UTME"
    ALL = "ALL"


class User(Base):
    __tablename__ = "users"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True, nullable=False)
    phone: Mapped[str] = mapped_column(String(40), unique=True, index=True, nullable=True)
    hashed_password: Mapped[str] = mapped_column(String(255), nullable=True)  # null for OAuth
    full_name: Mapped[str] = mapped_column(String(255), nullable=False)
    role: Mapped[UserRole] = mapped_column(Enum(UserRole), default=UserRole.student)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_verified: Mapped[bool] = mapped_column(Boolean, default=False)
    oauth_provider: Mapped[str] = mapped_column(String(50), nullable=True)  # google, apple
    oauth_id: Mapped[str] = mapped_column(String(255), nullable=True)
    profile_picture: Mapped[str] = mapped_column(String(1000), nullable=True)
    # Internationalization — user picks these at signup; language drives site translation
    country: Mapped[str | None] = mapped_column(String(80), nullable=True)
    language: Mapped[str | None] = mapped_column(String(10), nullable=True)  # en | fr | pt | ar
    # Bumped on each login so older JWTs on other devices stop working.
    token_version: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    # Sub-admin scoping: comma-separated permission keys. NULL/empty = full
    # (main) admin. Main admins create/remove sub-admins; nobody deletes a main admin.
    sub_admin_permissions: Mapped[str | None] = mapped_column(String(500), nullable=True)
    created_by_admin_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id"), nullable=True
    )
    school_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("school_campuses.id"), nullable=True, index=True
    )
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    student_profile: Mapped["StudentProfile"] = relationship(
        "StudentProfile",
        back_populates="user",
        uselist=False,
        foreign_keys="StudentProfile.user_id",
    )
    teacher_profile: Mapped["TeacherProfile"] = relationship("TeacherProfile", back_populates="user", uselist=False)
    vendor_profile: Mapped["VendorProfile"] = relationship("VendorProfile", back_populates="user", uselist=False)
    kind_profile: Mapped["KindProfile"] = relationship("KindProfile", back_populates="user", uselist=False)


class StudentProfile(Base):
    __tablename__ = "student_profiles"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), unique=True)
    exam_type: Mapped[ExamType] = mapped_column(Enum(ExamType), nullable=True)
    selected_subjects: Mapped[list] = mapped_column(ARRAY(String), default=[])
    cbt_subjects_locked: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    # Dual-board support (SS students can pick JAMB + WAEC/NECO)
    jamb_subjects: Mapped[list | None] = mapped_column(ARRAY(String), nullable=True)
    ssce_subjects: Mapped[list | None] = mapped_column(ARRAY(String), nullable=True)
    ssce_exam_type: Mapped[str | None] = mapped_column(String(20), nullable=True)  # WAEC | NECO
    # Per-board registration (WAEC and NECO each keep their own subject list)
    waec_subjects: Mapped[list | None] = mapped_column(ARRAY(String), nullable=True)
    neco_subjects: Mapped[list | None] = mapped_column(ARRAY(String), nullable=True)
    # Junior WAEC (BECE) keeps its own registration list too
    junior_subjects: Mapped[list | None] = mapped_column(ARRAY(String), nullable=True)
    education_level: Mapped[str] = mapped_column(String(50), nullable=True)  # JSS1, SS1, JAMB etc.
    school_student_id: Mapped[str | None] = mapped_column(String(40), nullable=True, index=True)
    has_active_subscription: Mapped[bool] = mapped_column(Boolean, default=False)
    live_plan_id: Mapped[str] = mapped_column(String(80), nullable=True)
    live_plan_expires_at: Mapped[datetime] = mapped_column(DateTime, nullable=True)
    live_plan_sessions_used: Mapped[int] = mapped_column(Integer, default=0)
    community_channel_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("community_channels.id"), nullable=True)

    # ===== AUDIT TRAIL FOR CBT SUBJECT LOCK =====
    # Tracks when the profile was locked and who locked it
    locked_at: Mapped[datetime] = mapped_column(DateTime, nullable=True)
    locked_by: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)

    # Relationships
    user: Mapped["User"] = relationship(
        "User",
        back_populates="student_profile",
        foreign_keys=[user_id],
    )
    # Relationship for the admin/teacher who locked the profile
    locked_by_user: Mapped["User"] = relationship("User", foreign_keys=[locked_by])


class TeacherProfile(Base):
    __tablename__ = "teacher_profiles"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), unique=True)
    subjects: Mapped[list] = mapped_column(ARRAY(String), default=[])
    academic_classes: Mapped[list | None] = mapped_column(ARRAY(String), nullable=True)
    bio: Mapped[str] = mapped_column(String(1000), nullable=True)
    location: Mapped[str] = mapped_column(String(255), nullable=True)
    is_approved: Mapped[bool] = mapped_column(Boolean, default=False)
    school_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("school_campuses.id"), nullable=True, index=True
    )

    user: Mapped["User"] = relationship("User", back_populates="teacher_profile")


class VendorProfile(Base):
    __tablename__ = "vendor_profiles"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), unique=True)
    business_name: Mapped[str] = mapped_column(String(255), nullable=False)
    location: Mapped[str] = mapped_column(String(255), nullable=True)
    address: Mapped[str] = mapped_column(String(500), nullable=True)
    whatsapp: Mapped[str] = mapped_column(String(40), nullable=True)
    nin: Mapped[str] = mapped_column(String(20), nullable=True)
    kyc_completed: Mapped[bool] = mapped_column(Boolean, default=False)
    categories: Mapped[list] = mapped_column(ARRAY(String), default=[])
    is_approved: Mapped[bool] = mapped_column(Boolean, default=False)

    user: Mapped["User"] = relationship("User", back_populates="vendor_profile")


class KindProfile(Base):
    """Young learner profile (Kind / kids mode)."""
    __tablename__ = "kind_profiles"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), unique=True)
    age_group: Mapped[str] = mapped_column(String(20), nullable=False, default="6-8")  # 3-5 | 6-8 | 9-12
    grade_level: Mapped[str] = mapped_column(String(50), nullable=True)  # Nursery, Primary 1, JSS1
    parent_email: Mapped[str] = mapped_column(String(255), nullable=True)
    favorite_subjects: Mapped[list] = mapped_column(ARRAY(String), default=[])
    learning_goals: Mapped[str] = mapped_column(String(500), nullable=True)
    preferred_language: Mapped[str] = mapped_column(String(30), default="english")

    user: Mapped["User"] = relationship("User", back_populates="kind_profile")